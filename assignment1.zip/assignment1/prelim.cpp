#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

int main () {
  char hostname[HOST_NAME_MAX];
  gethostname(hostname, sizeof(hostname));
  printf("The name of the current machine is '%s'.\n", hostname);
  return 0;
}
