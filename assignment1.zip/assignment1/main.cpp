#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>
#include <string>
#include <stdio.h>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

  
int main (int argc, char* argv[]) {

  if (argc < 6) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }

  int functionid = atoi(argv[1]);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  
  float sum = 0.0;

  auto timeStart = chrono::high_resolution_clock::now();
  
  for(int i = 0; i <= (n-1); i++){
    float x = (a + (i + 0.5) * ((float)(b-a)/n));
    switch(functionid){
    case 1: sum += f1(x, intensity);
      break;
    case 2: sum += f2(x, intensity);
      break;
    case 3: sum += f3(x, intensity);
      break;
    case 4: sum += f4(x, intensity);
      break;
    default: exit;
    }
  }
  float integral = sum * ((float)(b-a)/n);

  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cout << integral << endl;
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  
  return 0;
}
