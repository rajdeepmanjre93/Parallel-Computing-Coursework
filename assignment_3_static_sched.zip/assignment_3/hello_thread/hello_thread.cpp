#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

struct thread_data
{
  int thread_num;
  int nbthread;
};

void* print_id(void *thread_arg){

  struct thread_data *print_data;
  print_data = (struct thread_data *) thread_arg;
  printf("I am thread %d in %d\n", print_data->thread_num, print_data->nbthread);
  return NULL;
}

int main (int argc, char* argv[]) {

  if (argc < 2) {
    std::cerr<<"usage: "<<argv[0]<<" <nbthreads>"<<std::endl;
    return -1;
  }
  
  int nbthreads = atoi(argv[1]);
  pthread_t threads[nbthreads];
  
  struct thread_data td[nbthreads];
  
  for(int i = 1; i <= nbthreads; i++){
    td[i].thread_num = i;
    td[i].nbthread = nbthreads;
    pthread_create(&threads[i], NULL, print_id, (void *)&td[i]);
  }

  for (int i = 1; i <= nbthreads; i++)
    pthread_join(threads[i], NULL);
  
  return 0;
}
