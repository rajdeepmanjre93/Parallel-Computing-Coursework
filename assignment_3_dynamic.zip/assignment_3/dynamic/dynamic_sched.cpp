#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>
#include <cmath>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

int functionid, a, b, intensity, n, nbthreads, granularity;
float result = 0.0;
char* sync;
pthread_mutex_t lock_loop, lock_getnext;
int loop_done = 0, low_index = 0, high_index = 0;


struct thread_data
{
  int thread_num;
};


void getNext(int* begin, int* end) {
  int temp = 0;
  
  temp = low_index;
  low_index = low_index + granularity;
  if(low_index >= n){
    loop_done = 1;
  }
  high_index = (temp + granularity) - 1;
  *begin = temp;
  if(high_index >= n)
    *end = n-1;
  else
    *end = high_index;
}


void* iteration(void *threadarg){

  struct thread_data *tdata;
  tdata = (struct thread_data *) threadarg;
 
  while(loop_done != 1){
    int begin,end;
   
    pthread_mutex_lock(&lock_getnext);
    getNext(&begin, &end);
    pthread_mutex_unlock(&lock_getnext);
    
    for(int i = (begin); i <= (end) ; i++){
      
      float x = (a + (i + 0.5) * ((float)(b-a)/n));
      
      pthread_mutex_lock(&lock_loop);
      switch(functionid){
      case 1: result += f1(x, intensity);
	break;
      case 2: result += f2(x, intensity);
	break;
      case 3: result += f3(x, intensity);
	break;
      case 4: result += f4(x, intensity);
	break;
      default: exit;
      }
      pthread_mutex_unlock(&lock_loop);
    }
  }
  
  pthread_exit(NULL);
}

void* thread(void *threadarg){

  float sum = 0.0;                  //local variable
  struct thread_data *tdata;
  tdata = (struct thread_data *) threadarg;
 
  while(loop_done != 1){
    int begin,end;
   
    pthread_mutex_lock(&lock_getnext);
    getNext(&begin, &end);
    pthread_mutex_unlock(&lock_getnext);
    
    for(int i = (begin); i <= (end) ; i++){
      
      float x = (a + (i + 0.5) * ((float)(b-a)/n));
      
      switch(functionid){
      case 1: sum += f1(x, intensity);
	break;
      case 2: sum += f2(x, intensity);
	break;
      case 3: sum += f3(x, intensity);
	break;
      case 4: sum += f4(x, intensity);
	break;
      default: exit;
      }
    }
  }
 
  pthread_mutex_lock(&lock_loop);
  result += sum;                //updating thread specific local values to global result
  pthread_mutex_unlock(&lock_loop);
  
  pthread_exit(NULL);
}

void* chunk(void *threadarg){

  struct thread_data *tdata;
  tdata = (struct thread_data *) threadarg;
 
  while(loop_done != 1){
    int begin,end;
    float sum = 0.0;
    
    pthread_mutex_lock(&lock_getnext);
    getNext(&begin, &end);
    pthread_mutex_unlock(&lock_getnext);
    
    for(int i = (begin); i <= (end) ; i++){
     
      float x = (a + (i + 0.5) * ((float)(b-a)/n));
      
      
      switch(functionid){
      case 1: sum += f1(x, intensity);
	break;
      case 2: sum += f2(x, intensity);
	break;
      case 3: sum += f3(x, intensity);
	break;
      case 4: sum += f4(x, intensity);
	break;
      default: exit;
      }
      
    }
    pthread_mutex_lock(&lock_loop);
    result += sum;                //updating thread specific local values to global result
    pthread_mutex_unlock(&lock_loop);
  }
  
  pthread_exit(NULL);
}

int main (int argc, char* argv[]) {

  if (argc < 9) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync> <granularity>"<<std::endl;
    return -1;
  }

  functionid = atoi(argv[1]);
  a = atoi(argv[2]);
  b = atoi(argv[3]);
  n = atoi(argv[4]);
  intensity = atoi(argv[5]);
  nbthreads = atoi(argv[6]);
  sync = (argv[7]);
  granularity = atoi(argv[8]);

  pthread_mutex_init(&lock_loop, NULL);
  pthread_mutex_init(&lock_getnext, NULL);
  pthread_t threads[nbthreads];
  struct thread_data td[nbthreads];
  auto timeStart = chrono::high_resolution_clock::now();

  for(int i = 0; i < nbthreads; i++){
    td[i].thread_num = i;
    if(strcmp(sync,"thread") == 0)
      pthread_create(&threads[i], NULL, thread, (void *)&td[i]);
    else if(strcmp(sync,"chunk") == 0)
      pthread_create(&threads[i], NULL, chunk, (void *)&td[i]);
    else
      pthread_create(&threads[i], NULL, iteration, (void *)&td[i]);
  }

  for (int i = 0; i < nbthreads; i++)
    pthread_join(threads[i], NULL);

  //printf("%.2f\n", result);
  float integral = result * ((float)(b-a)/n);
  
  pthread_mutex_destroy(&lock_loop);
  pthread_mutex_destroy(&lock_getnext);
  
  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cout << integral << endl;
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  return 0;
}
