#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>
#include <cmath>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

//Global variables

int functionid, a, b, intensity, chunk, n, nbthreads;
float result;
char* sync;
pthread_mutex_t mutex;

//Structure for storing thread specific values

struct thread_data
{
  int thread_num;
  int low_index;
  int high_index;
  char* sync;
};

//Thread handler function for thread-level synchronization

void* thread(void *threadarg){

  struct thread_data *tdata;
  tdata = (struct thread_data *) threadarg;
  float sum = 0.0;                    //local variable

  for(int i = (tdata->low_index);
      i < (tdata->high_index) ;
      i++){
   
    float x = (a + (i + 0.5) * ((float)(b-a)/n));

    switch(functionid){
    case 1: sum += f1(x, intensity);
      break;
    case 2: sum += f2(x, intensity);
      break;
    case 3: sum += f3(x, intensity);
      break;
    case 4: sum += f4(x, intensity);
      break;
    default: exit;
    }
  }
  pthread_mutex_lock(&mutex);
  result += sum;                //updating thread specific local values to global result
  pthread_mutex_unlock(&mutex);

  pthread_exit(NULL);
}

// Thread handler function for iteration-level synchronization

void* iteration(void *threadarg){

  struct thread_data *tdata;
  tdata = (struct thread_data *) threadarg;
  
  
  for(int i = (tdata->low_index);
      i < (tdata->high_index) ;
      i++){
   
    float x = (a + (i + 0.5) * ((float)(b-a)/n));

    pthread_mutex_lock(&mutex);
    switch(functionid){                              
    case 1: result += f1(x, intensity);        //updating values directly to global variable
      break;
    case 2: result += f2(x, intensity);
      break;
    case 3: result += f3(x, intensity);
      break;
    case 4: result += f4(x, intensity);
      break;
    default: exit;
    }
    pthread_mutex_unlock(&mutex); 
  }
  
  pthread_exit(NULL);
}

int main (int argc, char* argv[]) {

  if (argc < 8) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync>"<<std::endl;
    return -1;
  }

  functionid = atoi(argv[1]);
  a = atoi(argv[2]);
  b = atoi(argv[3]);
  n = atoi(argv[4]);
  intensity = atoi(argv[5]);
  nbthreads = atoi(argv[6]);
  sync = (argv[7]);

  chunk = (n/nbthreads);
  pthread_t threads[nbthreads];
  struct thread_data td[nbthreads];

  pthread_mutex_init(&mutex, NULL);
  
  auto timeStart = chrono::high_resolution_clock::now();

  for(int i = 0; i < nbthreads; i++){
    td[i].thread_num = i;
    td[i].low_index = (i * chunk);
    if(i == nbthreads-1)
      td[i].high_index = n;
    else
      td[i].high_index = ((i+1) * chunk);
    td[i].sync = sync;
    if(strcmp(sync,"thread") == 0)
      pthread_create(&threads[i], NULL, thread, (void *)&td[i]);
    else
      pthread_create(&threads[i], NULL, iteration, (void *)&td[i]);
  }

  for (int i = 0; i < nbthreads; i++)
    pthread_join(threads[i], NULL);
  
  float integral = result * ((float)(b-a)/n);
  
  pthread_mutex_destroy(&mutex);
  
  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cout << integral << endl;
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  
  return 0;
}

