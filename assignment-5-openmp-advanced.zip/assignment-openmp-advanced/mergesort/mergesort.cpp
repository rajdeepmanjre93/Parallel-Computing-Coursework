#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>
#include <omp.h>
#include <chrono>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

  void generateMergeSortData (int* arr, size_t n);
  void checkMergeSortResult (int* arr, size_t n);

#ifdef __cplusplus
}
#endif

void merge(int *arr, int l, int mid, int r) 
{ 
  if (l == r) return;
  if (r-l == 1) {
    if (arr[l] > arr[r]) {
      int temp = arr[l];
      arr[l] = arr[r];
      arr[r] = temp;
    }
    return;
  }

  int i, j, k;
  int n = mid - l;
  
  // declare and init temp arrays
  int *temp = new int[n];
  for (i=0; i<n; ++i)
    temp[i] = arr[l+i];

  i = 0;    // temp left half
  j = mid;  // right half
  k = l;    // write to 

  // merge
  while (i<n && j<=r) {
     if (temp[i] <= arr[j] ) {
       arr[k++] = temp[i++];
     } else {
       arr[k++] = arr[j++];
     }
  }

  // exhaust temp 
  while (i<n) {
    arr[k++] = temp[i++];
  }

  // de-allocate structs used
  delete[] temp;
} 


void mergeSort(int *arr, int l, int r, int block) 
{
  if(l < r)
    {
      if ((r-l) <= block)
	{
	  int mid = (l+r)/2; 
	  
	  mergeSort(arr, l, mid, block);
	  mergeSort(arr, mid+1, r, block);
	  
	  merge(arr, l, mid+1, r);	  
	}
      else
	{
      	  int  mid = (l+r)/2;
	  
#pragma omp task
	  mergeSort(arr, l, mid, block);
#pragma omp task
	  mergeSort(arr, mid+1, r, block);
#pragma omp taskwait
	  merge(arr, l, mid+1, r); 	
	}
    }
}

int main (int argc, char* argv[]) {
  
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 3) { std::cerr<<"usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }
  
  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);
  int block = (n/nbthreads);
  
  // get arr data
  int * arr = new int [n];
  generateMergeSortData (arr, n);
  
  //insert sorting code here.
  
  omp_set_num_threads(nbthreads);
  
  auto timeStart = chrono::high_resolution_clock::now();
  
#pragma omp parallel
  {
#pragma omp single
    {
      mergeSort(arr, 0, n-1, block);
    }
  }
  
  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  
  checkMergeSortResult (arr, n);
  
  delete[] arr;
  
  return 0;
}
