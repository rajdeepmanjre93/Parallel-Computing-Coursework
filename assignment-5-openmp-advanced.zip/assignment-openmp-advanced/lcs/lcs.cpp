#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>
#include <omp.h>
#include <chrono>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif
  
  void generateLCS(char* X, int m, char* Y, int n);
  void checkLCS(char* X, int m, char* Y, int n, int result);
  
#ifdef __cplusplus
}
#endif

int lcs(char* X, int m, char* Y, int n) {
  
  int** C = new int*[m+1];
#pragma omp parallel for
  for (int i=0; i<=m; ++i) {
    C[i] = new int[n+1];
    C[i][0] = 0;
  }
#pragma omp parallel for
  for (int j=0; j<=n; ++j) {
    C[0][j] = 0;
  }

#pragma omp parallel for
    for(int b = 1; b <= n; b++)
  {
#pragma omp parallel for
  for(int a = 1; a <= m; a++)
    {
      if(X[a-1] == Y[b-1])
      {
        C[a][b] = C[a-1][b-1] + 1;
      }
      else
      { 
	C[a][b] = max(C[a-1][b], C[a][b-1]);
      }
    }
  }
 
  int result = C[m][n];
  
  for (int i=0; i<=m; ++i)
    { 
      delete[] C[i];
    }
  delete[] C;
  
  return result;
}



int main (int argc, char* argv[]) {
  
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 4) { std::cerr<<"usage: "<<argv[0]<<" <m> <n> <nbthreads>"<<std::endl;
    return -1;
  }
  
  int m = atoi(argv[1]);
  int n = atoi(argv[2]);
  int nbthreads = atoi(argv[3]);

  // get string data 
  char *X = new char[m];
  char *Y = new char[n];
  generateLCS(X, m, Y, n);
  
  
  //insert LCS code here.
  int result = -1; // length of common subsequence
  
  omp_set_num_threads(nbthreads);

  auto timeStart = chrono::high_resolution_clock::now();
  
  result = lcs(X,m,Y,n);
  
  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  
  checkLCS(X, m, Y, n, result);
  
  return 0;
}
