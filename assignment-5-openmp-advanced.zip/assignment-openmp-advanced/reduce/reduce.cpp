#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

  void generateReduceData (int* arr, size_t n);

#ifdef __cplusplus
}
#endif


float partial_sum(int arr[], int low, int high)
{
  float partialSum;
  
  for(int i = low; i <= high; ++i)
    partialSum += arr[i];

  return partialSum;

}

float sum(int arr[],int start, int end, int block)
{
  float x, y;

  if((end-start) <= block)
    return partial_sum(arr, start, end);

  else{
    int mid = (end+start)/2;
#pragma omp task 
    x = sum(arr, start, mid, block);
#pragma omp task
    y = sum(arr, mid + 1, end, block);
#pragma omp taskwait
    x += y;
    return x;
  }
  
  //return x;
}


int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 3) {
    std::cerr<<"usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);
  int * arr = new int [n];
  
  generateReduceData (arr, atoi(argv[1]));
  
  //insert reduction code here
 
  int block = (n/nbthreads);
  omp_set_num_threads(nbthreads);
  
  float result;
      
  auto timeStart = chrono::high_resolution_clock::now();

  #pragma omp parallel
  {
    #pragma omp single
    {
      result = sum(arr, 0, n-1, block);
    }
  }
	
  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cout << result << endl;
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  
  delete[] arr;

  return 0;
}
