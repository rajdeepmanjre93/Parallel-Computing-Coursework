#include <mpi.h>
#include <math.h>
#include <iostream>
#include <chrono>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

  int check2DHeat(double** H, long n, long rank, long P, long k); //this assumes array of array and grid block decomposition

#ifdef __cplusplus
}
#endif

/***********************************************
 *         NOTES on check2DHeat.
 ***********************************************
 *         
 *  First of, I apologize its wonky. 
 *
 *  Email me ktibbett@uncc.edu with any issues/concerns with this. Dr. Saule or the other
 *    TA's are not familiar with how it works. 
 *
 * Params:
 *  n - is the same N from the command line, NOT the process's part of N
 *  P - the total amount of processes ie what MPI_Comm_size gives you.
 *  k - assumes n/2 > k-1 , otherwise may return false negatives.
 *
 *   
 * Disclaimer:
 ***
 *** Broken for P is 9. Gives false negatives, for me it was always
 ***  ranks 0, 3, 6. I have not found issues with 1, 4, or 16, and these
 ***  are what `make test` will use.
 ***
 *
 * Usage:
 *  When code is WRONG returns TRUE. Short example below
 *  if (check2DHeat(...)) {
 *    // oh no it is (maybe) wrong  
 *    std::cout<<"rank: "<<rank<<" is incorrect"<<std::endl;
 *  }
 *
 *
 *
 *  I suggest commenting this out when running the bench
 *
 *
 * - Kyle
 *
 *************/


// Use similarily as the genA, genx from matmult assignment.
double genH0(long row, long col, long n) {
  double val = (double)(col == (n/2));
  return val;
}


void calculate_2d_heat(long block, double** H_Curr, double** H_Prev, double* recv_left, double* recv_right, double* recv_up, double* recv_down){

  int row, col;
  
  for (row = 0; row < block; ++row) { 
    for (col = 0; col < block; ++col) {
      if(row == 0){
	H_Curr[row][col] = (recv_up[col] + H_Prev[row][col-1] + H_Prev[row][col] + H_Prev[row][col+1] + H_Prev[row+1][col])/(static_cast<double>(5));
      }
      else if(row == block-1){
	H_Curr[row][col] = (recv_down[col] + H_Prev[row-1][col] + H_Prev[row][col-1] + H_Prev[row][col] + H_Prev[row][col+1])/(static_cast<double>(5));
      }
      else if(col == 0){
	H_Curr[row][col] = (recv_left[row] + H_Prev[row-1][col] + H_Prev[row][col] + H_Prev[row][col+1] + H_Prev[row+1][col])/(static_cast<double>(5));
      }
      else if(col == block-1){
	H_Curr[row][col] = (recv_right[row] + H_Prev[row-1][col] + H_Prev[row][col-1] + H_Prev[row][col]+ H_Prev[row+1][col])/(static_cast<double>(5));
      }
      else if(row == 0 && col == 0){
	H_Curr[row][col] = (recv_left[row] + recv_up[col] + H_Prev[row][col] + H_Prev[row][col+1] + H_Prev[row+1][col])/(static_cast<double>(5));
      }
      else if(row == block-1 && col == 0){
	H_Curr[row][col] = (recv_left[row] + recv_down[col] + H_Prev[row-1][col] + H_Prev[row][col] + H_Prev[row][col+1])/(static_cast<double>(5));
      }
      else if(row == 0 && col == block-1){
	H_Curr[row][col] = (recv_right[row] + recv_up[col] + H_Prev[row][col-1] + H_Prev[row][col] + H_Prev[row+1][col])/(static_cast<double>(5));
      }
      else if(row == block-1 && col == block-1){
	H_Curr[row][col] = (recv_right[row] + recv_down[col] + H_Prev[row-1][col] + H_Prev[row][col-1] + H_Prev[row][col])/(static_cast<double>(5));;
      }
      else{
	H_Curr[row][col] = (H_Prev[row-1][col] + H_Prev[row][col-1] + H_Prev[row][col] + H_Prev[row][col+1] + H_Prev[row+1][col])/(static_cast<double>(5));
      }
    }
  }
  
  for (row = 0; row < block; ++row) {
    for (col= 0; col < block; ++col) {
      H_Prev[row][col] = H_Curr[row][col];
    }
  }  
}

int main(int argc, char* argv[]) {

  if (argc < 3) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <N> <K>"<<std::endl;
    return -1;
  }

  MPI_Init(&argc, &argv);
  
  // declare and init command line params
  long N, K;
  N = atol(argv[1]);
  K = atol(argv[2]);

  // use double for heat 2d 

  // write code here
  
 int rank, numprocs;
 MPI_Comm_rank(MPI_COMM_WORLD, &rank);
 MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

 long sqrt_procs = sqrt(numprocs);
 long block = N/sqrt_procs;
 
 long row_rank = rank/sqrt_procs;
 long col_rank = rank%sqrt_procs;
  
 double** H_Prev = new double*[block];
 double** H_Curr = new double*[block];

 for(long i = 0;i < block; ++i){
    H_Prev[i]=(double*)malloc(block * sizeof(double));
    H_Curr[i]=(double*)malloc(block * sizeof(double));
  }


 for (long row = row_rank*block; row < (row_rank+1)*block; row++) {
   for (long col = col_rank*block; col < (col_rank+1)*block; col++) {
     H_Curr[(row-(row_rank*block))][(col-(col_rank*block))] = genH0(row, col, N);
     H_Prev[(row-(row_rank*block))][(col-(col_rank*block))] = H_Curr[(row-(row_rank*block))][(col-(col_rank*block))];
   }
 }

 MPI_Request* request;
 MPI_Status* status;
  
 double* send_left = new double[block];
 double* recv_left = new double[block];
 double* send_right = new double[block];
 double* recv_right = new double[block];
 double* recv_up = new double[block];
 double* recv_down = new double[block]; 

  MPI_Barrier(MPI_COMM_WORLD);
  
  std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();

  for(long iter = 1; iter <= K; ++iter){

    for(long i = 0;i<block;i++){
      recv_left[i]=H_Prev[i][0];
      recv_right[i]=H_Prev[i][(block-1)];
      recv_up[i]=H_Prev[0][i];
      recv_down[i]=H_Prev[(block-1)][i];
    }
    
    if(numprocs == 1){  
      
      calculate_2d_heat(block, H_Curr, H_Prev, recv_left, recv_right, recv_up, recv_down);

      check2DHeat(H_Curr, block, rank, sqrt_procs, iter);
      
    }
    else{
      
      if(row_rank == 0 && col_rank == 0){
	
	for(long i = 0; i < block; i++){
	  send_right[i] = H_Prev[i][block-1];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(H_Prev[block-1], block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[3]);

	MPI_Waitall(4, request, status);
      }
      
      else if(row_rank == 0 && col_rank == (sqrt_procs-1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_Prev[i][0];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(H_Prev[block-1], block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[3]);
	
	MPI_Waitall(4, request, status);
      }
      
      else if(row_rank == (sqrt_procs-1) && col_rank == 0){
	
	for(long i = 0; i < block; i++){
	  send_right[i] = H_Prev[i][block-1];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(H_Prev[0], block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[3]);
	
	MPI_Waitall(4, request, status);
      }
      
      else if(row_rank == (sqrt_procs - 1) && col_rank == (sqrt_procs - 1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_Prev[i][0];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(H_Prev[0], block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[3]);

	MPI_Waitall(4, request, status);
      }
      
      else if(row_rank == 0){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_Prev[i][0];
	  send_right[i] = H_Prev[i][block-1]; 
	}

	request = new MPI_Request[6];
	status = new MPI_Status[6];

	MPI_Isend(H_Prev[block-1], block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[5]);
	
	MPI_Waitall(6, request, status);
      }
      
      else if(row_rank == (sqrt_procs-1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_Prev[i][0];
	  send_right[i] = H_Prev[i][block-1]; 
	}

	request = new MPI_Request[6];
	status = new MPI_Status[6];

	MPI_Isend(H_Prev[0], block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[5]);

	MPI_Waitall(6, request, status);
      }
      
      
      else if(col_rank == 0){

	for(long i = 0; i < block; i++){
	  send_right[i] = H_Prev[i][block-1]; 
	}

	request = new MPI_Request[6];
	status = new MPI_Status[6];
	
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Isend(H_Prev[block-1], block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Isend(H_Prev[0], block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[5]);
	MPI_Waitall(6, request, status);
      }

      else if(col_rank == (sqrt_procs-1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i]=H_Prev[i][0];
	}
	
	request = new MPI_Request[6];
	status = new MPI_Status[6];

	MPI_Isend(H_Prev[0], block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(H_Prev[block-1], block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[5]);
	
	MPI_Waitall(6, request, status);
      }
      
      else{
	
	for(long i = 0; i < block; i++){
	  send_left[i]=H_Prev[i][0];
	  send_right[i]=H_Prev[i][block-1];
	}

	MPI_Request* request_r;
	MPI_Request* request_s;
	request_r = new MPI_Request[4];
	request_s = new MPI_Request[4];
	status = new MPI_Status[4];
	
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request_r[0]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request_r[1]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request_r[2]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request_r[3]);
	MPI_Isend(H_Prev[0], block, MPI_DOUBLE, rank-sqrt_procs, 0, MPI_COMM_WORLD, &request_s[0]);
	MPI_Isend(H_Prev[block-1], block, MPI_DOUBLE, rank+sqrt_procs, 0, MPI_COMM_WORLD, &request_s[1]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request_s[2]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request_s[3]);
	MPI_Waitall(4, request_r, status);
      }
      
      calculate_2d_heat(block, H_Curr, H_Prev, recv_left, recv_right, recv_up, recv_down);
      
      
      check2DHeat(H_Curr, block, rank, sqrt_procs, iter);
      
    }
    
  }

  MPI_Finalize();
   
  std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
  
  std::chrono::duration<double> elapsed_seconds = end-start;
  
  if(rank == 0){
    std::cerr<<elapsed_seconds.count()<<std::endl;
  }

  for(long i = 0; i< block; i++){
    delete H_Prev[i];
    delete H_Curr[i];
  }
  delete[] H_Curr;
  delete[] H_Prev;
  delete[] send_left;
  delete[] recv_left;
  delete[] send_right;
  delete[] recv_right;
  delete[] recv_up;
  delete[] recv_down;
  
  return 0;
}
