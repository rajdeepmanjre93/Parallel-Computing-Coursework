#include <mpi.h>
#include <iostream>

using namespace std;

int main (int argc, char* argv[]) {

  if (argc < 2) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <value>"<<std::endl;
    return -1;
  }
  
  int value = atoi(argv[1]);
  
  int rank;
  
  MPI_Init(&argc, &argv);
  
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  
  if(rank == 0){
    MPI_Send(&value, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
    
    MPI_Recv(&value, 1, MPI_INT, 1, 1, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
    
    cout << value << endl;
  }
  else if(rank == 1){
    MPI_Recv(&value, 1, MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);

    value += 2;
    
    MPI_Send(&value, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);
  }

  MPI_Finalize();
  
  return 0;
}
