#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>
#include <mpi.h>
#include <limits.h>
#include <unistd.h>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif
  
int main (int argc, char* argv[]) {
  
  if (argc < 6) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }
  
  int functionid = atoi(argv[1]);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  double x,integral, sum = 0.0;
  int rank, numprocs;

  auto timeStart = chrono::high_resolution_clock::now();

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

  MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

  for(int i = rank+1; i <= n; i += numprocs){
      x = (a + (i + 0.5) * ((float)(b-a)/n));
      switch(functionid){
      case 1:
	sum += f1(x, intensity);
	break;
      case 2:
	sum += f2(x, intensity);
	break;
      case 3:
	sum += f3(x, intensity);
	break;
      case 4:
	sum += f4(x, intensity); 
	break;
      default: exit;
      }
  }

  MPI_Reduce(&sum, &integral, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

  integral = integral * ((float)(b-a)/n);
  
  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;

  if(rank == 0){
    cout << integral << endl;
    cerr << chrono::duration<double>(timeEnd).count()<< endl;
  }
  
  MPI_Finalize();
  
  return 0;
}
