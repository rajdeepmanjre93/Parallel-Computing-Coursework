#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>
#include <mpi.h>

using namespace std;

float genA (int row, int col) {
  if (row > col)
    return 1.;
  else
    return 0.;
}

float genx0 (int i) {
  return 1.;
}


void checkx (int iter, long i, float xval) {
  if (iter == 1) {
    float shouldbe = i;
    if (fabs(xval/shouldbe) > 1.01 || fabs(xval/shouldbe) < .99 )
      std::cout<<"incorrect : x["<<i<<"] at iteration "<<iter<<" should be "<<shouldbe<<" not "<<xval<<std::endl;
  }

  if (iter == 2) {
    float shouldbe =(i-1)*i/2;
    if (fabs(xval/shouldbe) > 1.01 || fabs(xval/shouldbe) < .99)
      std::cout<<"incorrect : x["<<i<<"] at iteration "<<iter<<" should be "<<shouldbe<<" not "<<xval<<std::endl;
  }
}

int main (int argc, char*argv[]) {

  if (argc < 3) {
    std::cout<<"usage: "<<argv[0]<<" <n> <iteration>"<<std::endl;
  }

  MPI_Init(&argc, &argv);

  bool check = true;
  
  long n = atol(argv[1]);

  long iter = atol(argv[2]);

  int rank, numprocs;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

  long sqrt_procs = sqrt(numprocs);
  long block = n/sqrt_procs;

  long row_color = rank/sqrt_procs;
  long col_color = rank%sqrt_procs;
  
  //initialize data
  float* local_A = new float[block*block];

  for (long row = row_color*block; row<(row_color+1)*block; row++) {
    for (long col=col_color*block; col<(col_color+1)*block; col++) {
      local_A[(row-(row_color*block))*block+(col-(col_color*block))] = genA(row, col);
    }
  }

  float* local_x = new float[block];

  for (long i=row_color*block; i<(row_color+1)*block; ++i)
    local_x[i-(row_color*block)] = genx0(i);
  
  float* local_y = new float[block];
  
  MPI_Comm row_comm, col_comm;
  MPI_Comm_split(MPI_COMM_WORLD, row_color, rank, &row_comm);
  MPI_Comm_split(MPI_COMM_WORLD, col_color, rank, &col_comm);

  long row_rank = row_color;
  long col_rank = col_color;
  
  std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();
  
  for (int it = 0; it<iter; ++it) {

    for (long row = 0; row<block; ++row) {
      float sum = 0;
      
      for (long col = 0; col<block; ++col) {
	sum += local_x[col] * local_A[row*block+col];
      }
      
      local_y[row] = sum;
    }

    MPI_Reduce(local_y, local_x, block, MPI_FLOAT, MPI_SUM, row_rank, row_comm);
    
    if(row_color == col_color){
      if (check)
	for (long i = (row_color*block); i<(row_color+1)*block; ++i)
	  checkx (it+1, i, local_x[i-(row_color*block)]);
    }

    MPI_Bcast(local_x, block, MPI_FLOAT, col_rank, col_comm);
  }
  
  std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
  
  std::chrono::duration<double> elapsed_seconds = end-start;
    
  std::cerr<<elapsed_seconds.count()<<std::endl;
    
  delete[] local_A;
  delete[] local_x;
  delete[] local_y;

  MPI_Finalize();
  
  return 0;
}
