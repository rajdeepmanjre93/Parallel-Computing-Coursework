#include <mpi.h>
#include <unistd.h>
#include <iostream>
#include <limits.h>

using namespace std;

int main(int argc, char*argv[]) {

  int rank, size;
  char hostname[HOST_NAME_MAX];
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  gethostname(hostname, sizeof(hostname));
  cout<<"I am process "<<rank+1<<" out of "<<size<<". I am running on "<<hostname<<".\n";
  MPI_Finalize();
  return 0;
}
