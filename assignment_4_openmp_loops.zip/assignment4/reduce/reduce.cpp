#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <string.h>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif
  void generateReduceData (int* arr, size_t n);
#ifdef __cplusplus
}
#endif

int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 5) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);
  char* scheduling = argv[3];
  int granularity = atoi(argv[4]);
  int * arr = new int [n];

  omp_set_num_threads(nbthreads);

  omp_sched_t sched_type;
  
  if(strcmp(scheduling, "static") == 0)
    sched_type = omp_sched_static;
  if(strcmp(scheduling, "dynamic") == 0)
    sched_type = omp_sched_dynamic;
  if(strcmp(scheduling, "guided") == 0)
    sched_type = omp_sched_guided;
  
  omp_set_schedule(sched_type, granularity);
  
  generateReduceData (arr, atoi(argv[1]));

  //insert reduction code here

  auto timeStart = chrono::high_resolution_clock::now();
  
  float sum = 0.0;
#pragma omp parallel for reduction(+:sum) schedule(runtime)
  for(int i = 0; i < n; i++)
    sum += arr[i];

  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cout << sum << endl;
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  
  delete[] arr;

  return 0;
}
