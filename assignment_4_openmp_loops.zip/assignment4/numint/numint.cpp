#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <chrono>
#include <cmath>

using namespace std; 

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 9) {
    std::cerr<<"Usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }

  //insert code here

  int functionid = atoi(argv[1]);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  int nbthreads = atoi(argv[6]);
  char* scheduling = argv[7];
  int granularity = atoi(argv[8]);

  omp_set_num_threads(nbthreads);

  omp_sched_t sched_type;
  
  if(strcmp(scheduling, "static") == 0)
    sched_type = omp_sched_static;
  if(strcmp(scheduling, "dynamic") == 0)
    sched_type = omp_sched_dynamic;
  if(strcmp(scheduling, "guided") == 0)
    sched_type = omp_sched_guided;
  
  omp_set_schedule(sched_type, granularity);

  auto timeStart = chrono::high_resolution_clock::now();
  
  float sum = 0.0;
  
#pragma omp parallel for reduction(+:sum) schedule(runtime)
  for(int i = 0; i <= (n-1); i++){
    float x = (a + (i + 0.5) * ((float)(b-a)/n));
    switch(functionid){
    case 1:sum += f1(x, intensity);
      break;
    case 2:sum += f2(x, intensity);
      break;
    case 3:sum += f3(x, intensity);
      break;
    case 4:sum += f4(x, intensity);
      break;
    default: exit;
    }
  }

  float integral = sum * ((float)(b-a)/n);
  
  auto timeEnd = chrono::high_resolution_clock::now() - timeStart;
  
  cout << integral << endl;
  cerr << chrono::duration<double>(timeEnd).count()<< endl;
  
  return 0;
}
